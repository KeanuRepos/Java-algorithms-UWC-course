# CSC project
Below are the files used to solve the knapsack problem given to us.
This is a group project, and team members will be using github for the first time in order to collaborate, I will post guides that the members can use in order to better understand the process, and get up to date with the new terminology etc

# links that might be useful
https://www.youtube.com/watch?v=9cMWR-EGFuY&ab_channel=MadnessLabs
